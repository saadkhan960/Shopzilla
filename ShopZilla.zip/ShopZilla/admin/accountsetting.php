<?php
include("pages/php/dbcon.php");
session_start();
$email = $_SESSION['email'];
if (!isset($_SESSION['email'])) {
  header("Location: index.php"); // redirect to login page if user is not logged in
  exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/sweetalert.css">
    <!-- <link rel="stylesheet" href="assets/vendor/bootstrap/css/_transitions.scss"> -->
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <title>Account Setting</title>
</head>
<style>
  /* Chrome, Safari, Edge, Opera */
  input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
  .profile-pic-wrapper {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .pic-holder {
    text-align: center;
    position: relative;
    border-radius: 50%;
    width: 150px;
    height: 150px;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
  }
  
  .pic-holder .pic {
    height: 100%;
    width: 100%;
    -o-object-fit: cover;
    object-fit: cover;
    -o-object-position: center;
    object-position: center;
  }
  
  .pic-holder .upload-file-block,
  .pic-holder .upload-loader {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: rgba(90, 92, 105, 0.7);
    color: #f8f9fc;
    font-size: 12px;
    font-weight: 600;
    opacity: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
  }
  
  .pic-holder .upload-file-block {
    cursor: pointer;
  }
  
  .pic-holder:hover .upload-file-block,
  .uploadProfileInput:focus ~ .upload-file-block {
    opacity: 1;
  }
  
  .pic-holder.uploadInProgress .upload-file-block {
    display: none;
  }
  
  .pic-holder.uploadInProgress .upload-loader {
    opacity: 1;
  }
  
  /* Snackbar css */
  .snackbar {
    visibility: hidden;
    min-width: 250px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 14px;
    transform: translateX(-50%);
  }
  
  .snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
  }
  
  @-webkit-keyframes fadein {
    from {
      bottom: 0;
      opacity: 0;
    }
    to {
      bottom: 30px;
      opacity: 1;
    }
  }
  
  @keyframes fadein {
    from {
      bottom: 0;
      opacity: 0;
    }
    to {
      bottom: 30px;
      opacity: 1;
    }
  }
  
  @-webkit-keyframes fadeout {
    from {
      bottom: 30px;
      opacity: 1;
    }
    to {
      bottom: 0;
      opacity: 0;
    }
  }
  
  @keyframes fadeout {
    from {
      bottom: 30px;
      opacity: 1;
    }
    to {
      bottom: 0;
      opacity: 0;
    }
  }
  </style>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
       <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <?php
        include("include/header.php");
        ?>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <?php
        include("include/sidebar.php");
        ?>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="influence-profile">
                <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Setting</h3>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="dashboard.php" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Setting</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- content -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- profile -->
                        <!-- ============================================================== -->
                        <div class="col-xl-3 col-lg-3 col-md-5 col-sm-12 col-12">
                            <!-- ============================================================== -->
                            <!-- card profile -->
                            <!-- ============================================================== -->
                            <div class="card">
                                <div class="card-body ">
                                    <!-- <div class="user-avatar text-center d-block">
                                        <img src="assets/images/avatar-1.jpg" alt="User Avatar" class="rounded-circle user-avatar-xxl">
                                    </div> -->
                                    <!-- ----imageee--- -->
                                    <form  id="myform" method="post" enctype="multipart/form-data">
                                        <div class="profile-pic-wrapper">
                                           <div class="pic-holder">
                                            
                                            <img id="profilePic" class="pic" id="img" class="img" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($image); ?>">

                                            <Input class="uploadProfileInput" type="file" name="imgget" id="newProfilePhoto" accept="image/*" style="opacity: 0;" />
                                            <label for="newProfilePhoto" class="upload-file-block">
                                            <div class="text-center">
                                                <div class="mb-2">
                                                <i class="fa fa-camera fa-2x"></i>
                                                </div>
                                                <div class="text-uppercase">
                                                Update <br /> Profile Photo
                                                </div>
                                            </div>
                                            </label>
                                         </div>

                                           </hr>
                                        </div>
                                        <button type="submit" name="picbtn" id="picbtn" style="display: none;">click</button>
                                    </form>
                                    <!-- ----model-- -->
                                    <!-- Modal -->
                                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="myModalLabel">Selected Image</h4>
                                            </div>
                                            <div class="modal-body">
                                                <img id="selectedImg" class="img-responsive img-fluid" src="" >
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                <button type="button" class="btn btn-primary" id="submitBtn" name="submitBtn">Upload</button>
                                            </div>
                                            </div>
                                        </div>
                                        </div>

                                    <!-- ----------end imagee----- -->
                                    <div class="text-center">
                                        <h2 class="font-24 mb-0"><?php echo $name?></h2>
                                        <br>
                                        
                                        <p><i class="fas fa-user"></i>  <?php echo $role?></p>
                                        <p><i class="fas fa-phone"></i> <?php echo $number?></p>
                                        <p><i class="fas fa-envelope"></i> <?php echo $currentemail?></p>
                                    </div>
                                </div>
                                <!-- <div class="card-body border-top">
                                    <h3 class="font-16">Category</h3>
                                    <div>
                                        <a href="#" class="badge badge-light mr-1">Fitness</a><a href="#" class="badge badge-light mr-1">Life Style</a><a href="#" class="badge badge-light mr-1">Gym</a>
                                    </div>
                                </div> -->
                            </div>
                            <!-- ============================================================== -->
                            <!-- end card profile -->
                            <!-- ============================================================== -->
                        </div>
                        <!-- ============================================================== -->
                        <!-- end profile -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- campaign data -->
                        <!-- ============================================================== -->
                        <div class="col-xl-9 col-lg-9 col-md-7 col-sm-12 col-12">
                            <!-- ============================================================== -->
                            <!-- campaign tab one -->
                            <!-- ============================================================== -->
                            <div class="influence-profile-content pills-regular">
                                <ul class="nav nav-pills mb-3 nav-justified" id="pills-tab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="pills-general-tab" data-toggle="pill" href="#pills-general" role="tab" aria-controls="pills-campaign" aria-selected="true">General Information</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="pills-packages-tab" data-toggle="pill" href="#pills-packages" role="tab" aria-controls="pills-packages" aria-selected="false">Privite Information</a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-general" role="tabpanel" aria-labelledby="pills-general-tab">
                                        <div class="card">
                                            <div class="card-body">
                                                    <div class="row">
                                                        <div class="offset-xl-3 col-xl-6 offset-lg-3 col-lg-3 col-md-12 col-sm-12 col-12 p-4">
                                                            <!-- ------------------------- -->
                                                            <div id="accordion">
                                                                <div class="card text-center">
                                                                  <div class="card-header" id="headingTwo">
                                                                    <h5 class="mb-0">
                                                                      <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                                        CHANGE NAME
                                                                      </button>
                                                                    </h5>
                                                                  </div>
                                                                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                                                    <div class="card-body">
                                                                      <!-- --------- -->
                                                                      <form action="" id="nameform">
                                                                       <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="password">Current Password</label>
                                                                            <input class="form-control form-control-lg" type="password" name="" id="currpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="errorcurrpassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name">New Name</label>
                                                                            <input class="form-control form-control-lg" type="text" id="nname" autocomplete="off">
                                                                            <p id="errorname" class=""></p>
                                                                        </div>
                                                                        <div class="form-group pt-2">
                                                                            <button class="btn btn-block btn-primary" type="submit" name="cnbutton">Change Name</button>
                                                                        </div>
                                                    
                                                                        </div>
                                                                      </form>
                                                                      <!-- ------------------------- -->
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                                <div class="card text-center">
                                                                  <div class="card-header" id="headingThree">
                                                                    <h5 class="mb-0">
                                                                      <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                                        CHANGE NUMBER
                                                                      </button>
                                                                    </h5>
                                                                  </div>
                                                                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                                                    <div class="card-body">
                                                                     <!-- ------------------- -->
                                                                     <form action="" id="numberform">
                                                                     <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label>Current Password</label>
                                                                            <input class="form-control form-control-lg" type="password" name="" id="passcurrpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="errorpasscurrpassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="password">New Number</label>
                                                                            <input class="form-control form-control-lg" type="number" id="passnumber">
                                                                            <p id="errornumber" class=""></p>
                                                                        </div>
                                                                        <div class="form-group pt-2">
                                                                            <button class="btn btn-block btn-primary" type="submit" name="numchange">Change Number</button>
                                                                        </div>
                                                    
                                                                    </div>
                                                                    </form>
                                                                     <!-- ----------------------- -->
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            <!-- ------------------------- -->
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pills-packages" role="tabpanel" aria-labelledby="pills-packages-tab">
                                    <div class="card">
                                            <div class="card-body">
                                                    <div class="row">
                                                        <div class="offset-xl-3 col-xl-6 offset-lg-3 col-lg-3 col-md-12 col-sm-12 col-12 p-4">
                                                            <!-- ------------------------- -->
                                                            <div id="accordion">
                                                                <div class="card text-center">
                                                                  <div class="card-header" id="heading">
                                                                    <h5 class="mb-0">
                                                                      <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false" aria-controls="collapse">
                                                                        CHANGE PASSWORD
                                                                      </button>
                                                                    </h5>
                                                                  </div>
                                                                  <div id="collapse" class="collapse" aria-labelledby="heading" data-parent="#accordion">
                                                                    <div class="card-body">
                                                                      <!-- --------- -->
                                                                      <form action="" id="passform">
                                                                      <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label>Current Password</label>
                                                                            <input class="form-control form-control-lg" type="password" name="" id="Passwordcurrpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="errorCurrentPassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name">New Password</label>
                                                                            <input class="form-control form-control-lg" type="password" id="Newpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="errornewPassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name">Confirm New Password</label>
                                                                            <input class="form-control form-control-lg" type="password" id="Confirmpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="errorCpassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group pt-2">
                                                                            <button class="btn btn-block btn-primary" type="submit" name="cpbutton">Change Password</button>
                                                                        </div>
                                                    
                                                                    </div>
                                                                    </form>
                                                                      <!-- ------------------------- -->
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                                <div class="card text-center">
                                                                  <div class="card-header" id="headingone">
                                                                    <h5 class="mb-0">
                                                                      <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseone" aria-expanded="false" aria-controls="collapseone">
                                                                        CHANGE EMAIL
                                                                      </button>
                                                                    </h5>
                                                                  </div>
                                                                  <div id="collapseone" class="collapse" aria-labelledby="headingone" data-parent="#accordion">
                                                                    <div class="card-body" id="shape">
                                                                     <!-- ------------------- -->
                                                                     <form action="" id="emailform">
                                                                     <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label>Current Password</label>
                                                                            <input class="form-control form-control-lg" type="password" name="" id="emailcurrpassword" autocomplete="off" data-toggle="password">
                                                                            <p id="erroremailcurrpassword" class=""></p>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label>New Email</label>
                                                                            <input class="form-control form-control-lg" type="email" id="newemail">
                                                                            <p id="errornewemail" class=""></p>
                                                                        </div>
                                                                        <div class="form-group pt-2">
                                                                            <button class="btn btn-block btn-primary" type="submit" name="emailregister">Change Email</button>
                                                                        </div>
                                                    
                                                                        </div>
                                                                    </form>
                                                                     <!-- ----------------------- -->
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            <!-- ------------------------- -->
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- ============================================================== -->
                            <!-- end campaign tab one -->
                            <!-- ============================================================== -->
                        </div>
                        <!-- ============================================================== -->
                        <!-- end campaign data -->
                        <!-- ============================================================== -->
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end content -->
            <!-- ============================================================== -->
            <?php
             include("include/footer.php");
             ?>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end wrapper -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery  -->
    <script src="assets/vendor/jquery/jquery-3.6.0.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap-show-password.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/bootstrap/js/sweetalert.js"></script>
    <!-- slimscroll js -->
    <!-- <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script> -->
    <!-- main js -->
    <!-- <script src="assets/libs/js/main-js.js"></script> -->
    <script>var emailz = "<?php echo $email; ?>" ;</script>
    <script src="pages/js/logout.js"></script> 
    <script src="pages/js/internalcrud.js"></script>
</body>
</html>

<?php
include("pages/php/dbcon.php");
if(isset($_POST['picbtn']))
{
    // echo '<script>alert("wentdd wrong");</script>';
// $imagecheck = getimagesize($_FILES ['img']['tmp_name']); 
$imagesize = $_FILES['imgget']['tmp_name']; 
$image = addslashes(file_get_contents($imagesize));

$sql_email = "SELECT * FROM admins WHERE email = '$email'";
$result_email = $conn->query($sql_email);

if ($result_email->num_rows > 0) {

    $insert = $conn->query("UPDATE admins SET image = '$image' WHERE email = '$email'");
        if ($insert) {
            // echo '<script>alert("done");</script>';
            echo "
                  <script>
                      swal({
                          title: 'Success!',
                          text: 'Profile Picture Change Successfully',
                          type: 'success',
                          showCancelButton: false,
                          confirmButtonColor: '#28a745',
                          confirmButtonText: 'OK',
                          closeOnConfirm: true
                      }, function () {
                        location.href = 'accountsetting.php';
                      });
                  </script>
                  ";
        } else {
          echo '<script>alert("Something went wrong1");</script>';
        }
} 
else{
    echo '<script>alert("Something went wrong2");</script>';
}

}
else{
    // echo '<script>alert("fsdfsdf");</script>';
}


?>