<?php
include("pages/php/dbcon.php");
include("function.inc.php");
session_start();
$email = $_SESSION['email'];
if (!isset($_SESSION['email'])) {
  header("Location: index.php"); // redirect to login page if user is not logged in
  exit();
}
if(isset($_GET['type']) && $_GET['type'] !=''){
    $type= get_safe_value($conn,$_GET['type']);
    if($type == 'status'){
        $operation = get_safe_value($conn,$_GET['operation']);
        $id=get_safe_value($conn,$_GET['id']);
    }
    if($operation == 'activate'){
        $status = 1;
    }
    else{
        $status = 0;
    }
    $update_status="UPDATE categories set status= '$status' where id = '$id'";
    mysqli_query($conn,$update_status);
    header("Location: categories.php");

    if($type == 'delete'){
        $id=get_safe_value($conn,$_GET['id']);
        $delete_sql="DELETE from categories where id='$id'";
        mysqli_query($conn,$delete_sql);
        header("Location: categories.php");
        }
}

$sql = "SELECT * FROM categories order by categories asc";
$res=mysqli_query($conn,$sql);
$num_categories = mysqli_num_rows($res);
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/sweetalert.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" /> -->
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css"> -->
    <!-- <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Account Access</title>
</head>
<style>
    table tbody tr:nth-of-type(odd) {
        background-color: #fcfcfc;
        transition: background-color 0.1s ease-in-out;
    }

    table tbody tr:hover {
        background-color: #f5f5f5;
        transition: background-color 0.1s ease-in-out;
    }

    select.form-control {
        -webkit-appearance: menulist;
    }

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
</style>

<body>
    <!-------------- main wrapper ------------->
    <div class="dashboard-main-wrapper">
        <!----------------------- navbar ------------------------------->
        <?php
        include("include/header.php");
        ?>
        <!-----------------------end navbar ---------------------------->


        <!------------------------------- left sidebar ------------------------------->
        <?php
        include("include/sidebar.php");
        ?>
        <!------------------------------ end left sidebar ---------------------------->


        <!-- wrapper  -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content " id="chtml">
                    <!------------------------------- pageheader  ---------------------------------------->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h2 class="pageheader-title">Categories</h2>
                                    <button type="submit" class="btn btn-primary ml-auto btn-rounded" id="addcats">+ Add
                                        Cateogory</button>
                                        
                                </div>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="product.php" class="breadcrumb-link">Manage Products</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Categories</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--------------------------- end pageheader  ---------------------------->
                <!-- ----------------------BODY------------------------------------------------------------------------------------------------ -->
                <div class="row">
                        <!------------------------------- recent orders  -------------------------------------------->
                        <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Total Categories (<?php echo $num_categories;?>) <input type="text" class="form-control col-8 col-sm-6 col-lg-3 col-md-4" id="search-input" placeholder="Search..." autocomplete="off"></h5>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table ">
                                            <thead class="bg-light">
                                                <tr class="border-0">
                                                    <th class="border-0">#</th>
                                                    <th class="border-0">Id</th>
                                                    <th class="border-0">Categories</th>
                                                    <th class="border-0">Status</th>
                                                    <th class="border-0">Delete</th>
                                                    <th class="border-0">Edit</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody">
                                                <?php $i =1;
                                                while($row=mysqli_fetch_assoc($res)){?>
                                                <tr>
                                                    <td><?php echo $i++; ?></td>
                                                    <td><?php echo $row['id']; ?></td>
                                                    <td><?php echo $row['categories']; ?></td>
                                                    <td><?php 
                                                    if($row['status'] == 1){
                                                        echo "<a title='click to deactive' class='text-success' href='?type=status&operation=deactivate&id=".$row['id']."'>Active</a>";
                                                    }
                                                    else{
                                                        echo "<a title='click to Active' class='text-danger' href='?type=status&operation=activate&id=".$row['id']."'>Deactive</a>";
                                                    }
                                                     ?></td>
                                                     <td><?php
                                                     echo "<a title='Edit' class='showmodal text-primary' href='' data-sid='".$row['id']."'><i
                                                     class='fas fa-edit fa-lg'></i></a>";
                                                     ?></td>
                                                     <td><?php
                                                        echo "<a title='delete' class='text-danger' href='?type=delete&id=".$row['id']."'><i
                                                        class='fas fa-trash'></i></a>";
                                                     ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------------------- end recent orders  ------------------------------>
                    </div>
                <!-- ----------------------BODY------------------------------------------------------------------------------------------------ -->
                 <!-- --------------add category model----------------- -->
                 <div class="modal fade col-12" id="addCategory" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <form class="container" id="catform" autocomplete="on" method="post">
                                        <div class="card">
                                            <div class="card-header text-center">
                                                <h3 class="mb-1" id="headtxt">Enter New Category</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <!-- <label for="name">Category</label> -->
                                                    <input class="form-control form-control-lg" type="text" name="catinp"
                                                        id="category" autocomplete="off" placeholder="Category Name" value="">
                                                    <p id="errorcat" class=""></p>
                                                </div>
                                                <div class="form-group pt-2">
                                                    <button class="btn btn-block btn-primary" type="submit"
                                                        name="addcat">Add</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -------------------------end---------------- -->
                </div>

            </div>

            <!----------------- footer ----------------------->
            <?php
             include("include/footer.php");
             ?>

            <!------------------ end footer ---------------->

        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->

    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.6.0.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap-show-password.min.js"></script>
    <script src="pages/js/logout.js"></script>
    <script src="assets/vendor/bootstrap/js/sweetalert.js"></script>
    <script>
        $(document).ready(function () {
            // ------for seach tabel data-------------
            $('#search-input').on('input', function() {
                searchTable($(this).val().toLowerCase());
            });
            function searchTable(searchValue) {
                $('#tbody tr').each(function() {
                    var match = $(this).text().toLowerCase().indexOf(searchValue) !== -1;
                    $(this).toggle(match);
                });
            }
            // ------------------end-----------------
            let sid = null; // initialize sid to null

            // --add button click
        $('#addcats').click(function(){
            $("#headtxt").html("Enter New Category");
            sid = null; // clear sid when adding a new category
            $("#addCategory").modal("show");
            $("#category").val("");
        });

        // ------edit button click---
        $('.showmodal').click(function(e){
            e.preventDefault();
            $("#headtxt").html("Update Category Name");
            sid = $(this).attr("data-sid");
            mydata = { sid: sid };
            mythis = this;
            $.ajax({
            url:'pages/php/getcat.php',
            type:'POST',
            data:JSON.stringify(mydata),
            success:function(data){
                $("#category").val(data);
                $("#addCategory").modal("show");
            },
            error:function(data){
                alert("error");
                console.log(data);
            }
            });

        });
        //----------when both submit----
        $('#category').on('input', function () {
            if ($('#category').val() !== '') {
                $("#category").removeClass("is-invalid");
                $("#errorcat").removeClass('text-danger').html("");
            }
        });

        $('#catform').submit(function(z){
            z.preventDefault();
            var cats = $('#category').val();
            if (cats == "") {
                    $("#category").addClass("is-invalid");
                    $("#errorcat").addClass('text-danger').html("Category cant't be empty");
                    return false;
                }
                mydata = { sid: sid ,value: cats }; // pass sid to the server only if it's not null
                $.ajax({
                    url:'pages/php/dualcat.php',
                    method:'POST',
                    data: JSON.stringify(mydata),
                    success:function(data){
                        var datas = data;
                        if(datas.trim() == "Category already exist"){
                            $("#category").addClass("is-invalid");
                            $("#errorcat").addClass('text-danger').html("Category already exist.");
                        }
                        if(datas.trim() == "inserted"){
                            swal(
                            {
                                title: "Inserted!",
                                text: "New Category Inserted Successfully",
                                type: "success",
                                showCancelButton: false,
                                confirmButtonColor: "#28A745",
                                confirmButtonText: "OK",
                                closeOnConfirm: true
                            },
                            function () {
                                window.location.href = "categories.php";
                            });
                        }
                        if(datas.trim() == "updated"){
                            swal(
                            {
                                title: "Updated!",
                                text: "Category Updated Successfully",
                                type: "success",
                                showCancelButton: false,
                                confirmButtonColor: "#28A745",
                                confirmButtonText: "OK",
                                closeOnConfirm: true
                            },
                            function () {
                                window.location.href = "categories.php";
                            });
                        }
                    },
                    error:function(){
                        alert("Error");
                    }
                });

        });

    });//---mainclose
    </script>
</body>

</html>