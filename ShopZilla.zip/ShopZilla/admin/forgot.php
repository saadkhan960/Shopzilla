<?php
include("pages/php/dbcon.php");
session_start();
if (isset($_SESSION['email'])) {
  header("Location:dashboard.php"); // redirect to home page if user is already logged in
  exit();
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Change Password</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/sweetalert.css">
    <style>
        html,
        body {
            height: 100%;
        }

        body {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-align: center;
            align-items: center;
            padding-top: 40px;
            padding-bottom: 40px;
        }

        body.animate__animated {
            overflow-x: hidden;
        }

        .animate__animated.animate__slideOutLeft {
            animation-duration: 0.5s;
            animation-fill-mode: forwards;
            animation-name: slideOutLeft;
        }

        .animate__animated.animate__slideInRight {
            animation-duration: 0.5s;
            animation-fill-mode: forwards;
            animation-name: slideInRight;
        }

        @keyframes slideOutLeft {
            0% {
                transform: translateX(0%);
            }

            100% {
                transform: translateX(-100%);
            }
        }

        @keyframes slideInRight {
            0% {
                transform: translateX(100%);
            }

            100% {
                transform: translateX(0%);
            }
        }
    </style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- forgot password  -->
    <!-- ============================================================== -->
    <div class="splash-container">
        <div class="card">
            <div class="card-header text-center">
                <img class="logo-img img-fluid" width="250" src="assets/images/logo3.png" alt="logo">
            </div>
            <div class="card-body">
                <form method="post" id="myform">
                    <p>Don't worry, we'll send you an email to reset your password.</p>
                    <div class="form-group">
                        <input class="form-control form-control-lg" type="email" name="email" id="email"
                            placeholder="Your Email" autocomplete="off">
                        <p id="erroremail" class=""></p>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="resetBtn">Reset Password</button>
                    <div id="loading" class="d-none text-center my-3">
                        <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <p class="mt-2">Please wait while we verify your email and send a verification message.</p>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center">
                <span>Sign In Instead <a href="index.php">Click Here!</a></span>
            </div>
        </div>
    </div>





    <!-- <div class="splash-container">
        <div class="card">
            <div class="card-header text-center"><img class="logo-img img-fluid" width="250"
                    src="assets/images/logo3.png" alt="logo"></div>
            <div class="card-body">
                <form method="post" id="">
                    
                    <div class="form-group">
                        <label for="">New-password</label>
                        <input class="form-control form-control-lg" type="password" id="pass" placeholder="" autocomplete="off">
                        <p id="erropass" class=""></p>
                    </div>
                    <div class="form-group">
                        <label for="">Confirm new-password</label>
                        <input class="form-control form-control-lg" type="password" id="cpass" placeholder="" autocomplete="off">
                        <p id="errorcpass" class=""></p>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="changepass">Change Password</button>
                </form>
            </div>
        </div>
    </div> -->


</body>
<!-- ============================================================== -->
<!-- end forgot password  -->
<!-- ============================================================== -->
<!-- Optional JavaScript -->
<script src="assets/vendor/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap-show-password.min.js"></script>
<script src="assets/vendor/bootstrap/js/sweetalert.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<script>
    // ---------------email check before click on submit----------
    $(document).ready(function () {
        var email = $("#email").val();
        $('#email').on('input', function () {
            if ($('#email').val() !== '') {
                $("#email").removeClass("is-invalid");
                $("#erroremail").removeClass('text-danger').html("");
            }
        });
    });
    // ----------------Email Check---------------------
    $("#myform").submit(function (e) {
        e.preventDefault()
        let email = $("#email").val();
        var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

        if (!emailRegex.test(email)) {
            $("#email").addClass("is-invalid");
            $("#erroremail").addClass('text-danger').html("Please enter your valid Email Address");
            return false;
        }

        $mydata = { email: email };

        $("#resetBtn").addClass("d-none");
        $("#loading").removeClass("d-none");

        $.ajax({
            url: 'pages/php/forgotemail.php',
            method: 'POST',
            data: JSON.stringify($mydata),
            success: function (data) {
                var datas = data;
                if (datas.trim() == "success") {
                    swal(
                        {
                            title: "Success!",
                            text: "verfication code successfully send to your email",
                            type: "success",
                            showCancelButton: false,
                            confirmButtonColor: "#28A745",
                            confirmButtonText: "OK",
                            closeOnConfirm: true
                        },
                        function () {
                            $('body').addClass('animate__animated animate__slideOutLeft').fadeOut(500, function () {
                                var newHtml = '<div class="splash-container"><div class="card"><div class="card-header text-center"><img class="logo-img img-fluid" width="250" src="assets/images/logo3.png" alt="logo"></div><div class="card-body"><form method="post" id="verification-form"><p>Enter The Verfication Code Here.</p><div class="form-group"><input class="form-control form-control-lg" type="number" name="" id="verinp" placeholder="Verification Code" autocomplete="off"><p id="errorotes" class=""></p></div><button type="submit" id="versbtn" class="btn btn-primary btn-lg btn-block">Verify</button></form></div></div></div>'; // your new HTML content
                                $('body').removeClass('animate__slideOutLeft')
                                    .html(newHtml)
                                    .addClass('animate__slideInRight')
                                    .fadeIn(500, function () {
                                        $('body').removeClass('animate__slideInRight');
                                    });

                                // ---------------------verification code check-------------------------------------------------------
                                $('#verinp').on('input', function () {
                                    if ($('#verinp').val() !== '') {
                                        $("#verinp").removeClass("is-invalid");
                                        $("#errorotes").removeClass('text-danger').html("");
                                    }
                                });


                                $("#verification-form").submit(function (z) {
                                    z.preventDefault();
                                    let verfi = $("#verinp").val();
                                    if (verfi.trim().length < 5) {
                                        $("#verinp").addClass("is-invalid");
                                        $("#errorotes").addClass('text-danger').html("Please Enter 5 digits");
                                        return false;
                                    }
                                    $myver = { code: verfi, email: email };
                                    $.ajax({
                                        url: "pages/php/verification.php",
                                        method: "POST",
                                        data: JSON.stringify($myver),
                                        success: function (data) {
                                            var verdata = data;
                                            console.log(verdata);
                                            if (verdata.trim() == "success") {
                                                // alert("code match")
                                                // $('body').fadeOut(500, function () {
                                                //     // replace HTML with new HTML and fade in
                                                //     var newHtml = '<div class="splash-container"><div class="card"><div class="card-header text-center"><img class="logo-img img-fluid" width="250" src="assets/images/logo3.png" alt="logo"></div><div class="card-body"><form method="post" id=""><div class="form-group"><label for="">New-password</label><input class="form-control form-control-lg" type="password" id="pass" placeholder="" autocomplete="off"><p id="erropass" class=""></p></div><div class="form-group"><label for="">Confirm new-password</label><input class="form-control form-control-lg" type="password" id="cpass" placeholder="" autocomplete="off"><p id="errorcpass" class=""></p></div><button type="submit" class="btn btn-primary btn-lg btn-block" id="changepass">Change Password</button></form></div></div></div>';
                                                //     $('body').html(newHtml).fadeIn(500);
                                                // });
                                                $('body').addClass('animate__animated animate__slideOutLeft').fadeOut(500, function () {
                                                    var newsHtml = '<div class="splash-container"><div class="card"><div class="card-header text-center"><img class="logo-img img-fluid" width="250" src="assets/images/logo3.png" alt="logo"></div><div class="card-body"><form method="post" id="myform"><div class="form-group"><label for="">New-password</label><input class="form-control form-control-lg" type="password" id="password" placeholder="" autocomplete="off" data-toggle="password"><p id="errorpass" class=""></p></div><div class="form-group"><label for="">Confirm new-password</label><input class="form-control form-control-lg" type="password" id="cpassword" placeholder="" autocomplete="off" data-toggle="password"><p id="errorcpass" class=""></p></div><button type="submit" class="btn btn-primary btn-lg btn-block" id="changepass">Change Password</button></form></div></div></div>'; // your new HTML content
                                                    $('body').removeClass('animate__slideOutLeft')
                                                        .html(newsHtml)
                                                        .addClass('animate__slideInRight')
                                                        .fadeIn(500, function () {
                                                            $('body').removeClass('animate__slideInRight');
                                                        });
                                                    // -------------New Password Check and set-----------------------------------------------------------------//
                                                    $(document).ready(function () {
                                                        // ---------------------before click on submit---------------------
                                                        $('#password, #cpassword').on('input', function () {
                                                            if ($('#password').val() !== '') {
                                                                $("#password").removeClass("is-invalid");
                                                                $("#errorpass").removeClass('text-danger').html("");
                                                            }
                                                            if ($('#cpassword').val() !== '') {
                                                                $("#cpassword").removeClass("is-invalid");
                                                                $("#errorcpass").removeClass('text-danger').html("");
                                                            }
                                                        });
                                                        // --------------------when click on submit----------------
                                                        $("#myform").submit(function (e) {
                                                            e.preventDefault();
                                                            let password = $("#password").val();
                                                            let cpassword = $("#cpassword").val();

                                                            if (password.trim() == '' || password.trim().length < 8) {
                                                                $("#password").addClass("is-invalid");
                                                                $("#errorpass").addClass('text-danger').html("Please enter at least 8 character");
                                                                return false;
                                                            }
                                                            if (cpassword.trim() == '') {
                                                                $("#cpassword").addClass("is-invalid");
                                                                $("#errorcpass").addClass('text-danger').html("Please enter your password again");
                                                                return false;
                                                            }
                                                            if (password !== cpassword) {
                                                                $("#cpassword").addClass("is-invalid");
                                                                $("#errorcpass").addClass('text-danger').html("Those passwords didn`t match. Try again.");
                                                                return false;
                                                            }
                                                            $mydata = { password: password, email: email };
                                                            console.log($mydata);
                                                            $.ajax({
                                                                url: 'pages/php/newpass.php',
                                                                method: 'POST',
                                                                data: JSON.stringify($mydata),
                                                                success: function (data) {
                                                                    var datas = data;
                                                                    if (datas.trim() == "updated") {
                                                                        // alert("updated");
                                                                        $(window).off('beforeunload');
                                                                        swal(
                                                                            {
                                                                                title: "Success!",
                                                                                text: "Successfully Change Your Password.",
                                                                                type: "success",
                                                                                showCancelButton: false,
                                                                                confirmButtonColor: "#28A745",
                                                                                confirmButtonText: "OK",
                                                                                closeOnConfirm: true
                                                                            },
                                                                            function () {
                                                                                window.location.href = "index.php";
                                                                            });

                                                                    }
                                                                    if (datas.trim() == "Error updating") {
                                                                        // alert("Error updating");
                                                                        swal("Error1", "Something Went Wrong When try to Register Admin", "error");

                                                                    }
                                                                    if (datas.trim() == "error") {
                                                                        // alert("error");
                                                                        swal("Error2", "Something Went Wrong When try to Register Admin", "error");

                                                                    }

                                                                },
                                                                error: function () {
                                                                    alert("something went wrong");
                                                                }

                                                            });



                                                        });

                                                    });

                                                    // ----------------END New Password Check and set----------------------------------------------------------//
                                                });
                                            }
                                            // ------------------------//page reload alert---------------------
                                            $(window).on('beforeunload', function () {
                                                return 'The data you have entered may be lost if you leave this page. Are you sure you want to reload?';
                                            });
                                            // -----------------------------//page reload alert end -----------------
                                            if (verdata.trim() == "codeexpire") {
                                                // alert("code Expire. Please reset your password again")
                                                swal({
                                                    title: "Code Expire!",
                                                    // text: "Code Expire",
                                                    type: "Warning",
                                                    showCancelButton: false,
                                                    confirmButtonColor: "#DC3545",
                                                    confirmButtonText: "OK",
                                                    closeOnConfirm: true
                                                }, function () {
                                                    window.location.href = "login.php";
                                                });
                                            }
                                            if (verdata.trim() == "error") {
                                                // alert("Invalid verification code")
                                                $("#verinp").addClass("is-invalid");
                                                $("#errorotes").addClass('text-danger').html("Verification code incorrect");
                                            }
                                        },
                                        error: function () {

                                        }

                                    });

                                });
                                // ------------------------------------verification code check end--------------------------------------------------------
                            }) //------- fade out clseo tag--------
                        });//Sweet alert close tag
                }
                // ------------page reload alert
                $(window).on('beforeunload', function () {
                    return 'The data you have entered may be lost if you leave this page. Are you sure you want to reload?';
                });
                // ------------------------//page reload alert end-----

                if (datas.trim() == "Email not Found") {
                    $("#email").addClass("is-invalid");
                    $("#erroremail").addClass('text-danger').html("The email address you entered isn't connected to an account.Please enter correct email address");
                }
                if (data.trim() == "Message could not be sent. Mailer Error") {
                    alert("Message could not be sent. Mailer Error");
                }
                $("#resetBtn").removeClass("d-none");
                $("#loading").addClass("d-none");

            },
            error: function () {
                alert("something went wrong");

            }

        })


    })
</script>


</html>