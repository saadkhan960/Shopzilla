<?php
include("pages/php/dbcon.php");
session_start();
$email = $_SESSION['email'];
if (!isset($_SESSION['email'])) {
  header("Location: index.php"); // redirect to login page if user is not logged in
  exit();
}
$sql = "SELECT * FROM admins";
$rest=mysqli_query($conn,$sql);
$num_categoriez = mysqli_num_rows($rest);
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/sweetalert.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" /> -->
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css"> -->
    <!-- <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Account Access</title>
</head>
<style>
    table tbody tr:nth-of-type(odd) {
        background-color: #fcfcfc;
        transition: background-color 0.1s ease-in-out;
    }

    table tbody tr:hover {
        background-color: #f5f5f5;
        transition: background-color 0.1s ease-in-out;
    }

    select.form-control {
        -webkit-appearance: menulist;
    }

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
</style>

<body>
    <!-------------- main wrapper ------------->
    <div class="dashboard-main-wrapper">
        <!----------------------- navbar ------------------------------->
        <?php
        include("include/header.php");
        ?>
        <!-----------------------end navbar ---------------------------->


        <!------------------------------- left sidebar ------------------------------->
        <?php
        include("include/sidebar.php");
        ?>
        <!------------------------------ end left sidebar ---------------------------->


        <!-- wrapper  -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content " id="chtml">
                    <!------------------------------- pageheader  ---------------------------------------->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h2 class="pageheader-title">Account Access</h2>
                                    <button type="submit" class="btn btn-primary ml-auto btn-rounded" id="adduser">+ Add
                                        User</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--------------------------- end pageheader  ---------------------------->
                    <div class="row">
                        <!------------------------------- recent orders  -------------------------------------------->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Users (<?php echo $num_categoriez;?>) <input type="text" class="form-control col-8 col-sm-6 col-lg-2 col-md-4" id="search-input" placeholder="Search..." autocomplete="off"></h5>
                                <!-- <button type="button" class="btn btn-primary add-user-btn">Add User</button> -->

                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class="bg-light">
                                                <tr class="border-0">
                                                    <th class="border-0">Id</th>
                                                    <th class="border-0">Name</th>
                                                    <th class="border-0">Roles</th>
                                                    <th class="border-0">Number</th>
                                                    <th class="border-0">Position</th>
                                                    <th class="border-0">Edit</th>
                                                    <th class="border-0">Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody">
                                                <!-- <tr>
                                                    <td>
                                                        <p>1</p>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <img src="https://mdbootstrap.com/img/new/avatars/8.jpg"
                                                                alt="" style="width: 45px; height: 45px"
                                                                class="rounded-circle" />
                                                            <div class="ms-3">
                                                                <p class="fw-bold mb-1">John Doe</p>
                                                                <p class="text-muted mb-0">john.doe@gmail.com</p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="fw-normal mb-1">Admin</p>
                                                    </td>
                                                    <td>
                                                        03360361917
                                                    </td>
                                                    <td>
                                                        Senior
                                                    </td>
                                                    <td>
                                                        <a href="#" class="btn btn-link"><i
                                                                class="fas fa-edit fa-lg"></i></a>
                                                    </td>
                                                    <td>
                                                        <a href="#" class="btn btn-link text-danger"><i
                                                                class="fas fa-trash"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------------------- end recent orders  ------------------------------>
                    </div>
                    <!-- ----------edit form----hideen -->
                    <div class="modal fade" id="editModal" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Record</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <form id="editForm">
                                        <div class="form-group">
                                            <label for="stuid" class="col-form-label">ID:</label>
                                            <input type="text" class="form-control" id="stuid" name="stuid" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="nameid" class="col-form-label">Name:</label>
                                            <input type="text" class="form-control" id="nameid" name="nameid">
                                            <p id="errorname" class=""></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="emailid" class="col-form-label">Email:</label>
                                            <input type="email" class="form-control" id="emailid" name="emailid">
                                            <p id="erroremail" class=""></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="passwordid" class="col-form-label">Password:</label>
                                            <input type="password" class="form-control" id="passwordid"
                                                name="passwordid" data-toggle="password">
                                            <p id="errorpassword" class=""></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="passwordid" class="col-form-label">Number:</label>
                                            <input type="number" class="form-control" id="numberid" name="numberid">
                                            <p id="errornumber" class=""></p>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputState">Role</label>
                                            <select class="form-control" id="rolehtml" name="role">
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputState">Position</label>
                                            <select id="positionhtml" class="form-control" name="position">
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary" id="updateBtn">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -------------end------------- -->
                    <!-- --------------register model----------------- -->
                    <div class="modal fade col-12" id="registermodal" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <form class="container" autocomplete="on"
                                        id="myform">
                                        <div class="card">
                                            <div class="card-header text-center">
                                                <h3 class="mb-1">User Registration</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="name">Name</label>
                                                    <input class="form-control form-control-lg" type="text" name=""
                                                        id="fname" autocomplete="off">
                                                    <p id="errornames" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="email">Email</label>
                                                    <input class="form-control form-control-lg" type="email" name=""
                                                        id="email" autocomplete="off">
                                                    <p id="erroremails" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="password">Password</label>
                                                    <input class="form-control form-control-lg" type="password"
                                                        id="password" data-toggle="password">
                                                    <p id="errorpasswords" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="confirm-password">Confirm Password</label>
                                                    <input class="form-control form-control-lg" type="password"
                                                        data-toggle="password" id="cpassword">
                                                    <p id="errorcpasswords" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="phoneRegex">Phone Number</label>
                                                    <input class="form-control form-control-lg" type="number"
                                                        id="pnumber">
                                                    <p id="errorpnumbers" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputState">Role</label>
                                                    <select id="rolehtmls" class="form-control" name="roles">
                                                        <option value="Admin">Admin</option>
                                                        <option value="Assistant">Assistant</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputState">Position</label>
                                                    <select id="positionhtmls" class="form-control" name="positions">
                                                        <option value="Junior">Junior</option>
                                                        <option value="Senior">Senior</option>
                                                    </select>
                                                </div>
                                                <div class="form-group pt-2">
                                                    <button class="btn btn-block btn-primary" type="submit"
                                                        name="register">Register Account</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- -------------------------end---------------- -->



                </div>

            </div>

            <!----------------- footer ----------------------->
            <?php
             include("include/footer.php");
             ?>

            <!------------------ end footer ---------------->

        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->

    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.6.0.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap-show-password.min.js"></script>
    <script src="pages/js/logout.js"></script>
    <script src="assets/vendor/bootstrap/js/sweetalert.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script> -->
    <script>
        $(document).ready(function () {
            // ------for seach tabel data-------------
            $('#search-input').on('input', function() {
                searchTable($(this).val().toLowerCase());
            });
            function searchTable(searchValue) {
                $('#tbody tr').each(function() {
                    var match = $(this).text().toLowerCase().indexOf(searchValue) !== -1;
                    $(this).toggle(match);
                });
            }
            // ------------------end-----------------

            //---------AJAX REQUEST FOR SHOW DATA IN MYSQL DATABASE-----------//
            function showdata() {
                output = "";
                $.ajax({
                    url: "pages/php/retrieve.php",
                    method: "GET",
                    dataType: "json", //The dataType property specifies the type of data that is expected to be returned from the server.
                    success: function (data) {
                        if (data) {
                            x = data;
                        }
                        else {
                            x = "";
                        }
                        // + x[i].id +
                        for (i = 0; i < x.length; i++) {
                            output += '<tr>\
                                        <td>\
                                            <p>'+ x[i].id + '</p>\
                                        </td>\
                                        <td>\
                                            <div class="d-flex align-items-center">\
                                            <img src="data:image/jpg;charset=utf8;base64,' + x[i].image + '" alt="" style="width: 45px; height: 45px" class="rounded-circle" />\
                                                <div class="ms-3">\
                                                    <p class="fw-bold mb-1">'+ x[i].name + '</p>\
                                                    <p class="text-muted mb-0">'+ x[i].email + '</p>\
                                                </div>\
                                            </div>\
                                        </td>\
                                        <td>\
                                            <p class="fw-normal mb-1">'+ x[i].role + '</p>\
                                        </td>\
                                        <td>\
                                            '+ x[i].tel + '\
                                        </td>\
                                        <td>\
                                            '+ x[i].position + '\
                                        </td>\
                                        <td>\
                                            <a href="#" title="edit" class="btn btn-link btn-edit" data-sid= "' + x[i].id + '"><i class="fas fa-edit fa-lg"></i></a>\
                                        </td>\
                                        <td>\
                                            <a href="#" title="delete" class="btn btn-link text-danger btn-delete" data-sid= "' + x[i].id + '"><i class="fas fa-trash" ></i></a>\
                                        </td>\
                                    </tr>'
                        }

                        $('#tbody').html(output);
                    },
                    error: function () {
                        console.log("No Student Data Is Saved");
                    }
                });
            };
            showdata();

            //---------AJAX REQUEST FOR DELETE DATA IN MYSQL DATABASE-----------//
            $("#tbody").on('click', '.btn-delete', function () {
                let id = $(this).attr("data-sid");
                mydata = { sid: id };
                mythis = this;

                swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#DC3545',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }, function () {
                    $.ajax({
                        url: "pages/php/admindel.php",
                        method: "POST",
                        data: JSON.stringify(mydata),
                        success: function (data) {
                            if (data == 1) {
                                $(mythis).closest("tr").fadeOut(100);
                            } else if (data == 0) {
                                alert("unable to delete data");
                            }
                        },
                        error: function () {
                            console.log("ERROR:Something went wrong when try to Delete data");
                        }
                    });
                });
            });
            //---------------------------AJAX REQUEST FOR Edit DATA --------------------------//
            $("#tbody").on("click", ".btn-edit", function () {
                let id = $(this).attr("data-sid");
                let mydata = { sid: id };
                // Ajax request to retrieve data
                $.ajax({
                    url: "pages/php/adminedit.php",
                    method: "post",
                    dataType: "json",
                    data: JSON.stringify(mydata),
                    success: function (data) {
                        // Fill in the form fields with the retrieved data
                        $("#stuid").val(data.id);
                        $("#nameid").val(data.name);
                        $("#emailid").val(data.email);
                        $("#passwordid").val(data.password);
                        $("#numberid").val(data.tel);
                        var role = data.role;
                        if (role.trim() == "Admin") {
                            var newhtml = '<option value="Admin" selected>Admin</option><option value="Assistant">Assistant</option>';
                            $("#rolehtml").html(newhtml);
                        }
                        else {
                            var newhtml = '<option value="Assistant" selected>Assistant</option><option value="Admin">Admin</option>';
                            $("#rolehtml").html(newhtml);
                        }
                        var position = data.position;
                        // console.log(position);
                        if (position.trim() == "Senior") {
                            var newhtml = '<option value="Senior" selected>Senior</option><option value="Junior">Junior</option>';
                            $("#positionhtml").html(newhtml);
                        }
                        else {
                            var newhtml = '<option value="Junior" selected>Junior</option><option value="Senior">Senior</option>';
                            $("#positionhtml").html(newhtml);
                        }

                        var a = $("#editForm").serialize();
                        console.log(a);
                        // Show the modal
                        $("#editModal").modal("show");
                    },
                    error: function () {
                        console.log("ERROR:Something went wrong when try to Edit data");
                    }
                });
            });

            // Event listener for click on update button in modal form
            $("#updateBtn").click(function (e) {
                e.preventDefault();
                let name = $("#nameid").val();
                let email = $("#emailid").val();
                let password = $("#passwordid").val();
                let number = $("#numberid").val();
                var phoneRegex = /^03\d{9}$/;
                var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                //----------------------------------FIELD VALIDATION BEFORE CLICK ON SUBMIT-------------------

                $('#nameid, #emailid, #passwordid, #numberid').on('input', function () {
                    if ($('#nameid').val() !== '') {
                        $("#nameid").removeClass("is-invalid");
                        $("#errorname").removeClass('text-danger').html("");
                    }
                    if ($('#emailid').val() !== '') {
                        $("#emailid").removeClass("is-invalid");
                        $("#erroremail").removeClass('text-danger').html("");
                    }
                    if ($('#passwordid').val() !== '') {
                        $("#passwordid").removeClass("is-invalid");
                        $("#errorpassword").removeClass('text-danger').html("");
                    }
                    if ($('#numberid').val() !== '') {
                        $("#pnumber").removeClass("is-invalid");
                        $("#errorpnumber").removeClass('text-danger').html("");
                    }
                });
                // --------------------------------FIELD VALIDATION WHEN CLICK ON SUBMIT----------------------------------
                if (name.trim() == '') {
                    $("#errorname").addClass('text-danger').html("Please enter your name");
                    $("#nameid").addClass("is-invalid");
                    return false;
                }
                if (!emailRegex.test(email)) {
                    $("#emailid").addClass("is-invalid");
                    $("#erroremail").addClass('text-danger').html("Please enter valid Email Address");
                    return false;
                }
                if (password.trim() == '' || password.trim().length < 8) {
                    $("#passwordid").addClass("is-invalid");
                    $("#errorpassword").addClass('text-danger').html("Please enter at least 8 character");
                    return false;
                }
                if (!phoneRegex.test(number)) {
                    $("#numberid").addClass("is-invalid");
                    $("#errornumber").addClass('text-danger').html("Invalid phone number");
                    return false;
                }
                // Ajax request to submit form data
                $.ajax({
                    url: "pages/php/admineditupdate.php",
                    method: "post",
                    // dataType: "json",
                    data: $("#editForm").serialize(),
                    success: function (data) {
                        var datas = data;
                        console.log(datas);
                        if (datas.trim() == "success") {
                            // Close the modal
                            $("#editModal").modal("hide");
                            showdata();
                            swal("updated!", "selected user data successfully updated", "success");
                        }
                        else {
                            alert("wrongg");
                        }

                        // Refresh the table or do something else
                    },
                    error: function () {
                        console.log("ERROR:Something went wrong when try to update data");
                    }
                });
            });
            // --------------------------------ADD USER BUTTON-----------------------------------------------------//
            $("#adduser").click(function (e) {
                e.preventDefault()
                $("#registermodal").modal("show");
                    // -----------------------------------FIELD VALIDATION BEFORE CLICK ON SUBMIT-------------------
                    $('#fname, #email, #password, #cpassword, #pnumber').on('input', function () {
                        if ($('#fname').val() !== '') {
                            $("#fname").removeClass("is-invalid");
                            $("#errornames").removeClass('text-danger').html("");
                        }
                        if ($('#email').val() !== '') {
                            $("#email").removeClass("is-invalid");
                            $("#erroremails").removeClass('text-danger').html("");
                        }
                        if ($('#password').val() !== '') {
                            $("#password").removeClass("is-invalid");
                            $("#errorpasswords").removeClass('text-danger').html("");
                        }
                        if ($('#cpassword').val() !== '') {
                            $("#cpassword").removeClass("is-invalid");
                            $("#errorcpasswords").removeClass('text-danger').html("");
                        }
                        if ($('#pnumber').val() !== '') {
                            $("#pnumber").removeClass("is-invalid");
                            $("#errorpnumbers").removeClass('text-danger').html("");
                        }
                    });
                    // --------------------------------FIELD VALIDATION WHEN CLICK ON SUBMIT--------------------------------------//
                    $('#myform').submit(function (e) {
                        e.preventDefault();
                        // console.log("asdasd");
                        let name = $("#fname").val();
                        let email = $("#email").val();
                        let password = $("#password").val();
                        let cpassword = $("#cpassword").val();
                        let number = $("#pnumber").val();
                        let roles = $("#rolehtmls").val();
                        let positions = $("#positionhtmls").val();
                        var phoneRegex = /^03\d{9}$/;
                        var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

                        if (name.trim() == '') {
                            $("#errornames").addClass('text-danger').html("Please enter user name");
                            $("#fname").addClass("is-invalid");
                            return false;
                        }
                        if (!emailRegex.test(email)) {
                            $("#email").addClass("is-invalid");
                            $("#erroremails").addClass('text-danger').html("Please enter valid Email Address");
                            return false;
                        }
                        if (password.trim() == '' || password.trim().length < 8) {
                            $("#password").addClass("is-invalid");
                            $("#errorpasswords").addClass('text-danger').html("Please enter at least 8 character");
                            return false;
                        }
                        if (cpassword.trim() == '') {
                            $("#cpassword").addClass("is-invalid");
                            $("#errorcpasswords").addClass('text-danger').html("Please enter password again");
                            return false;
                        }
                        if (password !== cpassword) {
                            $("#cpassword").addClass("is-invalid");
                            $("#errorcpasswords").addClass('text-danger').html("Those passwords didn`t match. Try again.");
                            return false;
                        }
                        if (!phoneRegex.test(number)) {
                            $("#pnumber").addClass("is-invalid");
                            $("#errorpnumbers").addClass('text-danger').html("Invalid phone number");
                            return false;
                        }

                        // ----------------AJAX REQUEST FOR REGISTER ADMIN AND VERIFY EMAIL----------------------

                        mydata = { name: name, email: email, password: password, pnumber: number, role: roles, position: positions };
                        console.log(mydata);

                        $.ajax({
                            url: 'pages/php/registeremailcheck.php',
                            method: 'POST',
                            data: JSON.stringify(mydata),
                            success: function (data) {
                                var datas = data;
                                if (datas.trim() == "User Successfully Registered") {
                                    showdata();
                                    $("#registermodal").modal("hide");
                                    swal({
                                        title: "Registered!",
                                        text: "User Successfully Registered!",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#28a745",
                                        confirmButtonText: "OK",
                                        closeOnConfirm: true
                                    });
                                }
                                if (datas.trim() == "Email already exists") {
                                    $("#email").addClass("is-invalid");
                                    $("#erroremails").addClass('text-danger').html("That email taken. Try another.");
                                }
                                if (datas.trim() == "Phone number already exists") {
                                    $("#pnumber").addClass("is-invalid");
                                    $("#errorpnumbers").addClass('text-danger').html("Phone number already exists");
                                }
                                if (datas.trim() == "User Not Registered") {
                                    swal("Error!", "User Not Registered", "warning");
                                }

                            },
                            error: function () {
                                swal("Error!", "Something Went Wrong When try to Register Admin", "warning");
                            }


                        });

                    });
                
            });

        });//main close 
    </script>
</body>

</html>