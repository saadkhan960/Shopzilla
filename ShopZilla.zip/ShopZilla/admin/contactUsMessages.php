<?php
include("pages/php/dbcon.php");
include("function.inc.php");
session_start();
$email = $_SESSION['email'];
if (!isset($_SESSION['email'])) {
  header("Location: index.php"); // redirect to login page if user is not logged in
  exit();
}

// $sql = "SELECT products.*, categories.categories , vendors.vendor 
//         FROM products 
//         LEFT JOIN categories ON products.categories_id = categories.id 
//         LEFT JOIN vendors ON products.vendor = vendors.id 
//         ORDER BY products.id DESC";


$sql = "SELECT * FROM contactus ORDER BY id DESC ";

$res = mysqli_query($conn,$sql);
$num_messages = mysqli_num_rows($res);


if(isset($_GET['type']) && $_GET['type'] !=''){
    $type= get_safe_value($conn,$_GET['type']);
     if($type == 'delete'){
        $id=get_safe_value($conn,$_GET['id']);
        $delete_sql="DELETE from contactus where id='$id'";
        mysqli_query($conn,$delete_sql);
        header("Location:contactUsMessages.php");
        }
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/sweetalert.css">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" /> -->
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/chartist-bundle/chartist.css"> -->
    <!-- <link rel="stylesheet" href="assets/vendor/charts/morris-bundle/morris.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/material-design-iconic-font/css/materialdesignicons.min.css">
    <!-- <link rel="stylesheet" href="assets/vendor/charts/c3charts/c3.css"> -->
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>Account Access</title>
</head>
<style>
    table tbody tr:nth-of-type(odd) {
        background-color: #fcfcfc;
        transition: background-color 0.1s ease-in-out;
    }

    table tbody tr:hover {
        background-color: #f5f5f5;
        transition: background-color 0.1s ease-in-out;
    }

    select.form-control {
        -webkit-appearance: menulist;
    }

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    .success-text {
  display: inline-block;
  padding: 1px 7px;
  border-radius: 20px;
  background-color: #3bae56; /* green color */
  color: #f3f3f3; /* white font color */
  text-decoration: none;
  transition: background-color 0.2s ease-in-out; /* smooth transition */
}

.success-text:hover {
  background-color: #70c370; /* lighter shade of green */
  color: #f3f3f3;
}
.success-draft {
  display: inline-block;
  padding: 1px 7px;
  border-radius: 20px;
  background-color: #6ad7e8; /* green color */
  color: #f3f3f3; /* white font color */
  text-decoration: none;
  transition: background-color 0.2s ease-in-out; /* smooth transition */
}

.success-draft:hover {
  background-color: #85e4f3; /* lighter shade of green */
  color: #f3f3f3;
}
</style>

<body>
    <!-------------- main wrapper ------------->
    <div class="dashboard-main-wrapper">
        <!----------------------- navbar ------------------------------->
        <?php
        include("include/header.php");
        ?>
        <!-----------------------end navbar ---------------------------->


        <!------------------------------- left sidebar ------------------------------->
        <?php
        include("include/sidebar.php");
        ?>
        <!------------------------------ end left sidebar ---------------------------->


        <!-- wrapper  -->
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content " id="chtml">
                    <!------------------------------- pageheader  ---------------------------------------->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h2 class="pageheader-title">Contact US Messages</h2>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--------------------------- end pageheader  ---------------------------->
                <!-- ----------------------BODY------------------------------------------------------------------------------------------------ -->
                <div class="row">
                        <!------------------------------- recent orders  -------------------------------------------->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Total Products (<?php echo $num_messages;?>) <input type="text" class="form-control col-8 col-sm-6 col-lg-3 col-md-4" id="search-input" placeholder="Search..." autocomplete="off"></h5>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table ">
                                            <thead class="bg-light">
                                                <tr class="border-0">
                                                    <th class="border-0">#</th>
                                                    <th class="border-0">Id</th>
                                                    <th class="border-0">Name</th>
                                                    <th class="border-0">User Check</th>
                                                    <th class="border-0">Subject</th>
                                                    <th class="border-0">Submit Date</th>
                                                    <th class="border-0">Show message</th>
                                                    <th class="border-0">Delete</th>

                                                </tr>
                                            </thead>
                                            <tbody id="tbody">
                                                <?php $i =1;
                                                while($row=mysqli_fetch_assoc($res)){?>
                                                <tr>
                                                    <td><?php echo $i++; ?></td>

                                                    <td><?php echo $row['id']; ?></td>
                                                    <?php 
                                                    $userimage='';
                                                    if($row['user_ids'] !== "0"){
                                                    $databse_user_id = $row['user_ids'];
                                                    $collect = mysqli_query($conn,"SELECT * FROM users WHERE id = '$databse_user_id'");
                                                    $rowzs = mysqli_fetch_assoc($collect);
                                                    $userimage = $rowzs['userimage'];
                                                    }
                                                    ?>
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                        <img src="<?php echo ($userimage == null) ? 'data:image/jpg;charset=utf8;base64,' . base64_encode($row['imagecontact']) : 'data:image/jpg;charset=utf8;base64,' . base64_encode($userimage); ?>" alt="" style="width: 50px; height: 50px border; border:1px solid #dde0e2;" class="rounded mr-3" />
                                                            <div class="ms-3">
                                                                <p class="fw-bold"><?php echo $row['name']; ?></p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo $row['user_check']; ?></td>
                                                     <td><?php echo $row['subject']?></td>
                                                     <td><?php echo $row['date']?></td>
                                                     <td>
                                                    <button type="button"  class="btn btn-primary showmodals" data-sid="<?php echo $row['id']; ?>">Show</button>
                                                    </td>
                                                     <td><?php
                                                        echo "<a title='delete query' class='text-danger' href='?type=delete&id=".$row['id']."'><i class='fas fa-trash'></i></a>";
                                                     ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-------------------------- end recent orders  ------------------------------>
                    </div>
                <!-- ----------------------BODY------------------------------------------------------------------------------------------------ -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Contact Form Message</h5>
                                <a style="color:rgb(0, 42, 255);" data-dismiss="modal"><i class='fas fa-window-close'></i></a>
                            </div>
                            <div class="modal-body">
                                <p><strong>Name: </strong>name</p>
                                <p><strong>Subject: </strong>subject</p>
                                <p><strong>Email: </strong>email</p>
                                <p><strong>Submit Date: </strong>date</p>
                                <p><strong>Message: </strong>message</p>
                            </div>
                        </div>
                    </div>
                </div>
                

                
                    <!-- -------------------------end---------------- -->
                </div>

            </div>
                <!-- ----------------------BODY------------------------------------------------------------------------------------------------ -->
                <?php
             include("include/footer.php");
             ?>
                </div>
                

            </div>

            <!----------------- footer ----------------------->
            

            <!------------------ end footer ---------------->

        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->

    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 -->
    <script src="assets/vendor/jquery/jquery-3.6.0.min.js"></script>
    <!-- bootstap bundle js -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap-show-password.min.js"></script>
    <script src="pages/js/logout.js"></script>
    <script src="assets/vendor/bootstrap/js/sweetalert.js"></script>
    <script>
         // ------for seach tabel data-------------
      $('#search-input').on('input', function() {
                searchTable($(this).val().toLowerCase());
            });
            function searchTable(searchValue) {
                $('#tbody tr').each(function() {
                    var match = $(this).text().toLowerCase().indexOf(searchValue) !== -1;
                    $(this).toggle(match);
                });
            }
            // ------------------end-----------------
            $("#tbody").on("click", ".showmodals", function () {
                // $("#exampleModal").modal("show");
                let id = $(this).attr("data-sid");
                let mydata = { sid: id };
                $.ajax({
                    url: "pages/php/getcontactdata.php",
                    method: "POST",
                    data: JSON.stringify(mydata),
                    success: function(data){
                        var contactData = JSON.parse(data);

                    // Update the modal body with the contact data
                    $(".modal-body").html(
                        "<p><strong>Name: </strong>" + contactData.name + "</p>" +
                        "<p><strong>Subject: </strong>" + contactData.subject + "</p>" +
                        "<p><strong>Email: </strong>" + contactData.email + "</p>" +
                        "<p><strong>Submit Date: </strong>" + contactData.date + "</p>" +
                        "<p><strong>Message: </strong>" + contactData.message + "</p>"
                    );
                    // Show the modal
                    $("#exampleModal").modal("show");

                    },
                    error:function(){
                        alert("something went wrong");
                    }
                })
            });

    </script>
</body>

</html>