<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="en">
<head>

  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <title>User Address</title>

  <!-- Mobile Specific Metas
  ================================================== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Construction Html5 Template">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <meta name="author" content="Themefisher">
  <meta name="generator" content="Themefisher Constra HTML Template v1.0">
  
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
  
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="plugins/themefisher-font/style.css">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/sweetalert.css">
  
  <!-- Animate css -->
  <link rel="stylesheet" href="plugins/animate/animate.css">
  <!-- Slick Carousel -->
  <link rel="stylesheet" href="plugins/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick/slick-theme.css">
  
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="css/style.css">

</head>

<body id="body">
<body id="body">
<?php require("include/headermain.php"); 
// prx($_SESSION); 
?>
<section class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="content">
					<h1 class="page-name">Address</h1>
					<ol class="breadcrumb">
						<li><a href="index.php">Home</a></li>
						<li class="active">My Address</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="user-dashboard page-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <ul class="list-inline dashboard-menu text-center">
          <li><a href="dashboard.php">Dashboard</a></li>
          <li><a class="active" href="address.php">Address</a></li>
          <li><a href="profile-details.php">Profile Details</a></li>
        </ul>
        <div class="dashboard-wrapper user-dashboard">
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Street Address</th>
                  <th>City</th>
                  <th>Province</th>
                  <th>Country</th>
                  <th>Edit</th>
                </tr>
              </thead>
              <tbody>
              <?php
								$order_sql= mysqli_query($conn,"SELECT * from users where id = '$user_ids'");
								while($row= mysqli_fetch_assoc($order_sql)){ ?>
                <tr>
                  <td><?php echo $row['address']; ?></td>
                  <td><?php echo $row['city']; ?></td>
                  <td><?php echo $row['province']; ?></td>
                  <td>Pakistan</td>
                  <td>
                    <div class="btn-group" role="group">
                      <button type="button" class="btn btn-warning" id="editadd"><i class="tf-pencil2" aria-hidden="true"></i></button>
                    </div>
                  </td>
                </tr>
              <?php }; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- -----------------------------------------modal-------------------------------------->
<div class="modal fade col-12" id="addresschange" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <form autocomplete="on"
                                        id="myform">
                                        <div class="card">
                                            <div class="card-header text-center">
                                                <h3 class="mb-1">Edit Address</h3>
                                            </div>
                                            <div class="card-body">
                                                <div class="form-group">
                                                    <label for="name">Street Address</label>
                                                    <input class="form-control form-control-lg" type="text" name=""
                                                        id="street" autocomplete="off">
                                                    <p id="errorstreet" class=""></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputState">City</label>
                                                    <select id="city" class="form-control" name="cities">
                                                    <option value="Karachi">Karachi</option>
                                                    <option value="Lahore">Lahore</option>
                                                    <option value="Islamabad">Islamabad</option>
                                                    <option value="Rawalpindi">Rawalpindi</option>
                                                    <option value="Faisalabad">Faisalabad</option>
                                                    <option value="Multan">Multan</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="inputState">Province</label>
                                                    <select id="province" class="form-control" name="positions">
                                                    <option value="Punjab">Punjab</option>
                                                    <option value="Sindh">Sindh</option>
                                                    <option value="Khyber Pakhtunkhwa">Khyber Pakhtunkhwa</option>
                                                    <option value="Balochistan">Balochistan</option>
                                                    <option value="Gilgit-Baltistan">Gilgit-Baltistan</option>
                                                    <option value="Azad Jammu and Kashmir">Azad Jammu and Kashmir</option>
                                                    <option value="Islamabad Capital Territory">Islamabad Capital Territory</option>
                                                    </select>
                                                </div>
                                                <div class="form-group pt-2">
                                                    <button class="btn btn-block btn-main" type="submit"
                                                        name="register">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
<!-- ------------------------------------------------------------------------------------------- -->
    <!-- 
    Essential Scripts
    =====================================-->
    
    <!-- Main jQuery -->
    <script src="plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.1 -->
    <script src="plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/sweetalert.js"></script>
    <!-- Bootstrap Touchpin -->
    <script src="plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
    <!-- Instagram Feed Js -->
    <script src="plugins/instafeed/instafeed.min.js"></script>
    <!-- Video Lightbox Plugin -->
    <script src="plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
    <!-- Count Down Js -->
    <script src="plugins/syo-timer/build/jquery.syotimer.min.js"></script>

    <!-- slick Carousel -->
    <script src="plugins/slick/slick.min.js"></script>
    <script src="plugins/slick/slick-animation.min.js"></script>

    <!-- Google Mapl -->
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script> -->
    <script type="text/javascript" src="plugins/google-map/gmap.js"></script>

    <!-- Main Js File -->
    <script src="js/script.js"></script>
    <script src="js/removecartheader.js" ></script>
    <script>
      // -------------------data enter----------------------------
      $("#editadd").click(function(e){
        e.preventDefault();
        $.ajax({
          url:"include/php/addresschange.php",
          method:"GET",
          success:function(data){
            datas= JSON.parse(data);;
            // console.log(datas);
            // Assume that the 'datas' variable contains the array of objects

            // Get the city and province values from the first object in the array
            var city = datas[0].city;
            // console.log(city);
            var province = datas[0].province;

            // Set the street address input value
            $('#street').val(datas[0].address);

            // Set the selected option in the city dropdown
            $('#rolehtmls').val(city);

            // Set the selected option in the province dropdown
            $('#positionhtmls').val(province);

            // Show the modal
            $('#addresschange').modal('show');

          },
          erorr:function(){
            alert('error');
          }
        });

      })

      // -------------------------------------------
    // --------------------------------FIELD VALIDATION PROCESS------------------------------------
    $("#myform").submit(function(e){
      e.preventDefault();
      var street = $("#street").val();
      var city = $("#city").val();
      var province = $("#province").val();
      var user_id = "<?php echo $_SESSION['USER_ID']?>"

      if (street.trim() == '') {
          $("#errorstreet").addClass('text-danger').html("street address cant be empty");
          return false;
      }
      if (city.trim() == '') {
          $("#errorcity").addClass('text-danger').html("city cant be empty");
          return false;
      }
      if (province.trim() == '') {
          $("#errorprovince").addClass('text-danger').html("province cant be empty");
          return false;
      }

      $mydata={street:street,city:city,province:province,id:user_id};
      // console.log($mydata);
      $.ajax({
        url:"include/php/addresssave.php",
        method:"POST",
        data: JSON.stringify($mydata),
        success:function(data){
          var datas = data;
          if(datas.trim() == "done"){
            swal({
                  title: "Changed!",
                  text: "Address Change Successfully",
                  type: "success",
                  showCancelButton: false,
                  confirmButtonColor: "#28a745",
                  confirmButtonText: "OK",
                  closeOnConfirm: true
              }, function () {
                  // location.href = 'index.php';
                  location.reload();

              });
          }
          else{
            console.log(data);
          }
        },
        error:function(data){
          alert("Something went Wrong Error 404");
        }
      });
    });
    // -----------------------------------------------------------------------------------------------
    </script>


  </body>
  </html>